import 'package:flutter/material.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:provider/provider.dart';
import 'package:spoti_stream_music/pages/mainScreen.dart';
import 'package:spoti_stream_music/pages/playLIstScreen.dart';
import 'package:spoti_stream_music/providers/artistsProvider.dart';

import 'package:spoti_stream_music/providers/currentIndexMusicState.dart';
import 'package:spoti_stream_music/providers/imagePlayListAndAlbumState.dart';
import 'package:spoti_stream_music/providers/keyPlayreState.dart';
import 'package:spoti_stream_music/providers/pageState.dart';
import 'package:spoti_stream_music/providers/AudioPLayerProvider.dart';
import 'package:spoti_stream_music/providers/playMusicBarState.dart';
import 'package:spoti_stream_music/providers/typeReproducer.dart';

void main() async {
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider(create: (_) => ArtistProvider()),
      ChangeNotifierProvider(create: (_) => Keyplayrestate()),
      ChangeNotifierProvider(
        create: (context) => PageState(),
      ),
      ChangeNotifierProvider(
        create: (context) => AudioPLayerProvider(),
      ),
      ChangeNotifierProvider(
        create: (context) => CurrentIndexMusicState(),
      ),
      ChangeNotifierProvider(
        create: (context) => PlayMusicBarState(),
      ),
      ChangeNotifierProvider(
        create: (context) => ImagePlayListAndAlbumstate(),
      ),
      ChangeNotifierProvider(
        create: (context) => TypereproducerState(),
      ),
      ChangeNotifierProvider(
        create: (context) => AudioPLayerProvider(),
      )
    ],
    child: const MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(colorScheme: const ColorScheme.dark()),
      initialRoute: "/",
      routes: {
        "/": (context) => const MainScreen(),
        "/playlist": (context) => const Playlistscreen()
      },
    );
  }
}
