class PositionData {
  const PositionData(this.position, this.bufferedPOsition, this.duration);

  final Duration position;
  final Duration bufferedPOsition;
  final Duration duration;
}
